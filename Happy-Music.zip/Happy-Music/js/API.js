var callbackGetSuccess = function(data){
	console.log("données météo",data)
	var element = document.getElementById("zone_meteo");
	var temp = Math.round((data.main.temp-273.15)); // convertit les Kelvin en Celsius
	element.innerHTML = "La température à "+data.name+" est actuellement de " + temp +"°C</br> Le vent souffle à une vitesse de "+ data.wind.speed +" m/s</br> L'humidité est de "+ data.main.humidity+" %</br>La présence de nuages s'élève à "+ data.clouds.all +" %</br> La pression atmospherique est de "+ data.main.pressure +" hPa</br> Temps : "+ data.weather[0].main;
}

var callbackArtistsGetSuccess = function(data){
	console.log("données musique",data)
	document.getElementById("zone_artiste1").innerHTML = data.topartists.artist[0].name;
	document.getElementById("zone_artiste2").innerHTML = data.topartists.artist[1].name;
	document.getElementById("zone_artiste3").innerHTML = data.topartists.artist[2].name;
}
var callbackTracksGetSuccess = function(data){
	console.log("données musique",data)
	document.getElementById("zone_chanson1").innerHTML = data.tracks.track[0].name+" - "+data.tracks.track[0].artist.name;
	document.getElementById("zone_chanson2").innerHTML = data.tracks.track[1].name+" - "+data.tracks.track[1].artist.name;
	document.getElementById("zone_chanson3").innerHTML = data.tracks.track[2].name+" - "+data.tracks.track[2].artist.name;
	document.getElementById("zone_chanson4").innerHTML = data.tracks.track[3].name+" - "+data.tracks.track[3].artist.name;
}


function buttonClickGET(){
	var queryLoc = document.getElementById("queryLoc").value;
	var url = "http://api.openweathermap.org/data/2.5/weather?q="+queryLoc+"&APPID=015ea62f4649ea556cbc680654c56b29"

	$.get(url,callbackGetSuccess).done(function(){})
	.fail(function(){
		element.innerHTML = "Erreur";
	})
	.always(function(){});


}

function buttonClickArtistsGET(){
	var queryLoc = document.getElementById("queryLoc").value;
	switch(queryLoc) {
		case 'Algiers,dz':
			queryLoc = "algeria";
			break;
		case 'Berlin,de':
			queryLoc = "germany";
			break;
	    case 'Canberra,au':
			queryLoc = "australia";
			break;
		case 'Brussels,be':
			queryLoc = "belgium";
			break;	
		case 'Brasilia,br':
			queryLoc = "brasil";
			break;	
		case 'Ottawa,ca':
			queryLoc = "canada";
			break;	
		case 'Beijing,cn':
			queryLoc = "china";
			break;	
		case 'Bogota,co':
			queryLoc = "colombia";
			break;		
		case 'Cairo,eg':
			queryLoc = "egypt";
			break;	
		case 'Madrid,es':
			queryLoc = "spain";
			break;							
		case 'Paris,fr':
			queryLoc = "france";
			break;
		case 'Rome,it':
			queryLoc = "italy";
			break;	
		case 'Tokyo,jp':
			queryLoc = "japan";
			break;		
		case 'Rabat,ma':
			queryLoc = "maroc";
			break;	
		case 'Amsterdam,nl':
			queryLoc = "netherlands";
			break;		
		case 'Dakar,sn':
			queryLoc = "senegal";
			break;
		case 'Bern,ch':
			queryLoc = "switzerland";
			break;	
		case 'Ankara,tr':
			queryLoc = "turkey";
			break;
		case 'Kyiv,ua':
			queryLoc = "ukraine";
			break;			

	}

	var url2 = "http://ws.audioscrobbler.com/2.0/?method=geo.gettopartists&country="+queryLoc+"&api_key=def4813fceee3826f646d0305d0a87b9&format=json"
	
	$.get(url2,callbackArtistsGetSuccess).done(function(){})
	.fail(function(){
		element.innerHTML = "Erreur";
	})
	.always(function(){});	

}


function buttonClickTracksGET(){
	var queryLoc = document.getElementById("queryLoc").value;
	switch(queryLoc) {
		case 'Algiers,dz':
			queryLoc = "algeria";
			break;
		case 'Berlin,de':
			queryLoc = "germany";
			break;
	    case 'Canberra,au':
			queryLoc = "australia";
			break;
		case 'Brussels,be':
			queryLoc = "belgium";
			break;	
		case 'Brasilia,br':
			queryLoc = "brasil";
			break;	
		case 'Ottawa,ca':
			queryLoc = "canada";
			break;	
		case 'Beijing,cn':
			queryLoc = "china";
			break;	
		case 'Bogota,co':
			queryLoc = "colombia";
			break;		
		case 'Cairo,eg':
			queryLoc = "egypt";
			break;	
		case 'Madrid,es':
			queryLoc = "spain";
			break;							
		case 'Paris,fr':
			queryLoc = "france";
			break;
		case 'Rome,it':
			queryLoc = "italy";
			break;	
		case 'Tokyo,jp':
			queryLoc = "japan";
			break;		
		case 'Rabat,ma':
			queryLoc = "maroc";
			break;	
		case 'Amsterdam,nl':
			queryLoc = "netherlands";
			break;		
		case 'Dakar,sn':
			queryLoc = "senegal";
			break;
		case 'Bern,ch':
			queryLoc = "switzerland";
			break;	
		case 'Ankara,tr':
			queryLoc = "turkey";
			break;
		case 'Kyiv,ua':
			queryLoc = "ukraine";
			break;			

	}
	var url3 = "http://ws.audioscrobbler.com/2.0/?method=geo.gettoptracks&country="+queryLoc+"&api_key=def4813fceee3826f646d0305d0a87b9&format=json"
	$.get(url3,callbackTracksGetSuccess).done(function(){})
		.fail(function(){
			element.innerHTML = "Erreur";
		})
		.always(function(){});
}		

