var callbackGetSuccess = function(data){
	console.log("données météo",data)
	var element = document.getElementById("zone_meteo");
	var temp = (data.main.temp-273.15); // convertit les Kelvin en Celsius
	var nuages="Grand soleil"
	element.innerHTML = "La température est de " + temp +"°C</br> Le vent va à une vitesse de "+ data.wind.speed +" m/s</br> Temps : "+ data.weather[0].main+"</br> Nuages : "+ data.clouds.all +"%";
}

function buttonClickGET(){
	var queryLoc = document.getElementById("queryLoc").value;
	var url = "http://api.openweathermap.org/data/2.5/weather?q="+queryLoc+"&APPID=015ea62f4649ea556cbc680654c56b29"

	$.get(url,callbackGetSuccess).done(function(){})
	.fail(function(){
		element.innerHTML = "Erreur";
	})
	.always(function(){});
}